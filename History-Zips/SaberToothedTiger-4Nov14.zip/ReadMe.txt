Product: Saber Toothed Tiger, November 2014

Designer: Juan Esteban Paz

Support:  http://forums.obrary.com/category/designs/saber-toothed-tiger

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design
